<?php
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "user";
	
	$conn = new mysqli($host, $user, $pass, $db);
	if($conn)
	{	
	}
	else
	{
		echo "not connected".mysqli_connect_error();
    }
?>
