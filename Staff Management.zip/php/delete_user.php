<?php
	include '../config/config.php';
    
	$id = $_REQUEST['id'];

		$query = "DELETE FROM record WHERE id = '$id'";
        if(mysqli_query($conn, $query))
			{
                header('location: ./show_user.php');
			}
		else
			{
				echo"Error";
			}



?>
