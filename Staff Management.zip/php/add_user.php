<?php
include '../config/config.php';
if($_SERVER['REQUEST_METHOD']=='POST')
	{
	
		$user_name=$_POST['name'];
		$user_email=$_POST['email'];
		$user_position=$_POST['position'];


		$insert_query="INSERT INTO record(Name,Email,Position) VALUES ('$user_name','$user_email','$user_position')";
		
		if(mysqli_query($conn, $insert_query))
			{
        header('location: ./show_user.php');

			}
		else
			{
				echo"Error";
			}

	}



?>

