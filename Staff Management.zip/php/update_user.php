<?php
include '../config/config.php';

if($_SERVER['REQUEST_METHOD']=='POST')
	
	{
		$u_id=$_POST['id'];
		$u_name=$_POST['name'];
		$u_email=$_POST['email'];
		$u_position=$_POST['position'];

		$update_query="update record SET Name='$u_name', Email='$u_email', Position='$u_position' WHERE id='$u_id'";
		if(mysqli_query($conn, $update_query))
			
			{
				header('location: ./show_user.php');

			}
            else{
                echo"Error";
            }
	}
?>