<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="../css/show.css" />
    <title>Staff Member</title>
  </head>
  <body>
    <div>
      <div class="form-style">
        <fieldset>
          <legend><span class="number">1</span> User Database</legend>
        </fieldset>
      </div>
      <div class="main">
       <form action="../html/add_user.html" method="post">
       <input id="myInput" onkeyup="myFunction()"class="au-input--w300 au-input--style2" type="text" placeholder="Search"/>
          <a href="../html/add_user.html">
            <button value="Submit" class="btn" role="button">Add Staff</button>
          </a>
          <form>
        <table class="styled-table" id="myTable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>position</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
          <?php
								include '../config/config.php';
								$select = "SELECT * FROM record";
								$result = $conn->query($select);
								while($row = $result->fetch_assoc()){
							?>
            <tr>
            <td><?php echo $row['id'] ?></td>
            <td><?php echo $row['Name'] ?></td>
            <td><?php echo $row['Email'] ?></td>
            <td><?php echo $row['Position'] ?></td>
            <?php echo "<td><a href='../php/edit_user.php?id=".$row['id']."'>Edit</a></td>"?>
            <?php echo "<td><a href='../php/delete_user.php?id=".$row['id']."'>Delete</a></td>"?>
              <!-- <td><a href="../php/edit_user.php">Edit</a></td>
              <td><a href="../php/delete_user.php">Delete</a></td> -->
            </tr>
            <?php }?>

            
          </tbody>
        </table>
      </div>
    </div>
  </body>
</html>
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[3];
    tdd = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
