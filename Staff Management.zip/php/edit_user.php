<?php
      include '../config/config.php';


     $u_id=$_GET['id'];

     $select="select * from record WHERE id='$u_id'";

     $result=mysqli_query($conn, $select);


     $data=mysqli_fetch_assoc($result);

     $u_id=$data['id'];
     $u_name=$data['Name'];
     $u_email=$data['Email'];
     $u_position=$data['Position'];
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="../css/add.css" />
    <title>Edit User</title>
  </head>
  <body>
    <div class="form-style">
      <form action="./update_user.php" method="post">
      
        <fieldset>
          <legend><span class="number">1</span> User Info</legend>
          <label for="id">ID:</label>
          <input type="number" name="id" placeholder="ID " value="<?php echo $u_id?>" readonly/>
          <label for="name">Name:</label>
          <input type="text" name="name" placeholder="Your Name " value="<?php echo $u_name?>"/>
          <label for="email">Email:</label>
          <input type="email" name="email" placeholder="Your Email " value="<?php echo $u_email?>"/>
          <label for="position">Position:</label>
          <select id="job" name="position" for="postion" value="<?php echo $u_position?>">
              <option value="Lecturer">Lecturer</option>
              <option value="Reader">Reader</option>
              <option value="Professor">Professor</option>
              <option value="Senior Lecturer">Senior Lecturer</option>
          </select>
        </fieldset>
        <input type="submit" value="Submit" />
      </form>
    </div>
  </body>
</html>

