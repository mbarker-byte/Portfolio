<?php
$action=$_POST['action'];

if ($action=="insertsearch") {
	insertsearch();
}

elseif ($action=="getsearch") {
	getsearch();
}


function connect(){
$user="root";
$password="";
$host="localhost";
$db_name="recent_searches";
$con= new mysqli($host,$user,$password,$db_name);
return $con;

}



function getsearch(){
	$con=connect();
						///include 'connect.php';

						$sql=$_POST['sql'];
						if(mysqli_query($con,$sql)){	

						$result = mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($result)){
	 																$array[]=$row;
																	}

					$json_arr = array("status"=>"true","message"=>"Data fetched successfully!","data"=> $array);

						echo json_encode($json_arr);
					}

}



function insertsearch(){
	//include 'connect.php';
	$con=connect();
						$sql=$_POST['sql'];
						if(mysqli_query($con,$sql)){	

						
					$json_arr = array("status"=>"true","message"=>"Data inserted  successfully!","data"=> "null");

						echo json_encode($json_arr);

}else{
	echo json_encode(["message"=>"data insertion error",
"status"=>mysqli_error($con)]);
}
}
?>
