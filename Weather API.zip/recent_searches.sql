-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2022 at 08:35 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `recent_searches`
--

-- --------------------------------------------------------

--
-- Table structure for table `recent_searches`
--

CREATE TABLE `recent_searches` (
  `id` int(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `weather` varchar(100) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recent_searches`
--

INSERT INTO `recent_searches` (`id`, `location`, `weather`, `date`) VALUES
(14, 'birmingham', 'Mist', '2022-12-12 07:09:02.644440'),
(15, 'birmingham', 'Mist', '2022-12-12 07:09:04.400821'),
(16, 'london', 'Clouds', '2022-12-12 07:09:08.819835'),
(17, 'wales', 'Clear', '2022-12-12 07:09:22.561703'),
(18, 'oslo', 'Clouds', '2022-12-12 07:09:28.483908'),
(19, 'helsinki', 'Clouds', '2022-12-12 07:09:34.280757'),
(20, 'helsinki', 'Clouds', '2022-12-12 07:09:35.469739'),
(21, 'st petersburg', 'Clear', '2022-12-12 07:09:45.493815'),
(22, 'iceland', 'Clouds', '2022-12-12 07:09:58.377363'),
(23, 'wales', 'Clear', '2022-12-12 07:11:24.824576'),
(24, 'wales', 'Clear', '2022-12-12 07:11:46.931269'),
(25, 'wales', 'Clear', '2022-12-12 07:22:24.382579'),
(26, 'london', 'Clouds', '2022-12-12 07:22:32.028675'),
(27, 'ontario', 'Clouds', '2022-12-12 07:22:40.388581'),
(28, 'ontario', 'Clouds', '2022-12-12 07:22:41.198601'),
(29, 'antarctica', 'Clouds', '2022-12-12 07:22:54.351350'),
(30, 'birmingham', 'Mist', '2022-12-12 07:23:01.621693'),
(31, 'wakefield', 'Clear', '2022-12-12 07:23:20.264049'),
(32, 'manchester', 'Mist', '2022-12-12 07:23:25.167057'),
(33, 'belfast', 'Clouds', '2022-12-12 07:23:29.527037'),
(34, 'africa', 'Clear', '2022-12-12 07:23:33.706190'),
(35, 'wales', 'Clear', '2022-12-12 07:28:45.374374'),
(36, 'wales', 'Clear', '2022-12-12 07:30:52.743603'),
(37, 'birmingham', 'Mist', '2022-12-12 07:35:30.112676');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `recent_searches`
--
ALTER TABLE `recent_searches`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `recent_searches`
--
ALTER TABLE `recent_searches`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
