

<html>
<head>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
        

<style>

    *,
*::after,
*::before {
  margin: 0;
  padding: 0;
  box-sizing: inherit;
  font-size: 62,5%;
}

body {
  height: 100vh;
    width: 100%;
  background: #0f2027; /* fallback for old browsers */
  background: linear-gradient(to right,#2c5364, #203a43, #0f2027);
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  color: #fff;

}

.form__label {
  font-family: Verdana;
  font-size: 1.2rem;
  margin-left: 2rem;
  margin-top: 0.1rem;
  display: block;
  transition: all 0.3s;
  transform: translateY(0rem);
}

.form__input {
  font-family: Verdana;
  color: #333;
  font-size: 1.2rem;
    margin: 0 auto;
  padding: 1.5rem 2rem;
  border-radius: 0.2rem;
  background-color: rgb(255, 255, 225);
  border: none;
  width: 90%;
  display: block;
  border-bottom: 0.3rem solid transparent;
  transition: all 0.3s;
}

.form__input:placeholder-shown + .form__label {
  opacity: 0;
  visibility: hidden;
  -webkit-transform: translateY(-4rem);
  transform: translateY(-4rem);
}
.btn{
    color:#fff;
    background-color:#e74c3c;
    outline: none;
    border: 0;
    color: #fff;
    padding:10px 20px;
    text-transform:uppercase;
    margin-top:10px;
    margin-left: 30px;
    border-radius:2px;
    cursor:pointer;
    position:relative;
}

#mytable{
   
}
#tablediv
{
    background-color: teal;
    margin-left: 100px;
    border-radius: 20px;
    height: 500px;
    overflow: scroll;
    visibility:hidden
            
}

#mytable td
{
    padding: 30px;
}

</style>

    </head>
    <body class="body">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<div class="form__group">
  <input type="text" class="form__input" id="startLocation" placeholder="location" required="" />
  <label for="name" id="formloc" class="form__label"></label>

  <button type="button" class="btn" onclick="search()">submit</button> <button type="button" onclick="getsearch()" class="btn">History</button>
</div>

<div id="tablediv">
    <h3 style="margin-left:12rem;margin-top:30px;">History</h3>

<table id="mytable">
  <thead>
    <td>Location</td>
    <td>Weather</td>
    <td>Date</td>
  </thead>
 
    <tbody id="mybody"></tbody>
</table>
</div>
<?php




$url = 'http://api.openweathermap.org/data/2.5/weather?q=nairobi&appid=e237f5345891e2db4987d0303723ab2e';

$crl = curl_init($url);
curl_setopt($crl, CURLOPT_POST, 1);

curl_setopt($crl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($crl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($crl);
$arr = json_decode($result, true);

// echo $arr["weather"][0]['main'];
// echo $result;
?>


<script>
hidetable();

function search(){
   var location= $("#startLocation").val()
    $.ajax({
        url: "http://api.openweathermap.org/data/2.5/weather?q="+location+"&appid=e237f5345891e2db4987d0303723ab2e",
        type:"GET",
        data:{
          
        
          
        },
        success:function(response){

           


          console.log(response.weather);
           $.map(response.weather, function(val, i) {
              console.log (val.main);
               savesearch(location,val.main);

               $('#formloc').text(val.main);

            console.log(val.main.includes("Clouds"))
           
            if (val.main.includes("Clouds")) {
               

                      let css_property =
        {
            'background-image':'url("https://i.pinimg.com/736x/be/6c/fa/be6cfa6f04a65836ddeb13f83c77d383.jpg")',
            'background-repeat':'no-repeat',
            'background-size':'cover'

        }
         $("body").css(css_property);


        }
        else if(val.main.includes("Clear")){

      let css_property =
        {
            'background-image':'url("https://d1pra95f92lrn3.cloudfront.net/media/thumb/9192_fit512.jpg")',
            'background-repeat':'no-repeat',
            'background-size':'cover'

        }
         $("body").css(css_property);

        }
          
        else if(val.main.includes("Mist")){

      let css_property =
        {
            'background-image':'url("https://live.staticflickr.com/123/331894151_03e847533d_b.jpg")',
            'background-repeat':'no-repeat',
            'background-size':'cover'

        }
         $("body").css(css_property);

        }
		      else if(val.main.includes("Fog")){

      let css_property =
        {
            'background-image':'url("https://live.staticflickr.com/123/331894151_03e847533d_b.jpg")',
            'background-repeat':'no-repeat',
            'background-size':'cover'

        }
         $("body").css(css_property);

        }
		        else if(val.main.includes("Snow")){

      let css_property =
        {
            'background-image':'url("https://i.pinimg.com/736x/c8/b6/c6/c8b6c6400987f876e2425d8ff1c3b18c.jpg")',
            'background-repeat':'no-repeat',
            'background-size':'cover'

        }
         $("body").css(css_property);

        }
          
  		        else if(val.main.includes("Storm")){

      let css_property =
        {
            'background-image':'url("https://cdn.britannica.com/57/150357-050-427E4C4F/lightning-discharge-field-cumulonimbus-cloud.jpg")',
            'background-repeat':'no-repeat',
            'background-size':'cover'

        }
         $("body").css(css_property);

        }
        
          else if(val.main.includes("Rain")){

      let css_property =
        {
            'background-image':'url("https://notife.com/wp-content/uploads/2019/05/59459099_10217255296148386_4718481917840719872_n.jpg")',
            'background-repeat':'no-repeat',
            'background-size':'cover'

        }
         $("body").css(css_property);

        } 



      

             })
          
          
        },
        error: function(response) {
            $('#formloc').text("error finding location");

let css_property =
        {
            'color':'red',
            
        }
         $("#formloc").css(css_property);

        

          console.log(response)
         
         }
       });
}




function savesearch(location,weather){

    hidetable();
$.ajax({
        url: "savesearch.php",
        type:"post",
        data:{
          sql:"insert into recent_searches(location,weather) values ('"+location+"','"+weather+"')",
          action:"insertsearch"
        
          
        },
        success:function(response){


        console.log(response)
           $.map(response.weather, function(val, i) {
              console.log (val.main);

              

      

             })

          
          
        },
        error: function(response) {
            // $('#formloc').text("error finding location");



          console.log(response)
         
         }
       });

    }

    function getsearch(){
        showtable();
var location= $("#startLocation").val()

        
$.ajax({
        url: "savesearch.php",
        type:"post",
        data:{
          sql:"select * from recent_searches where location='"+location+"'",
          action:"getsearch"
        
          
        },
        success:function(response){
            hidetable()
             $('#mybody').empty();
            


        

        var point = JSON.parse(response);
        
        console.log(point.data)
          


           $('#mybody').empty();
            
          
            $.map(point.data, function(val, i) {
                showtable()

            
                console.log(val.location)

              var htmtable=' <tr><td>'+val.location+'</td><td>'+val.weather+'</td><td>'+val.date+'</td>  </tr>'
              
              $('#mybody').append(htmtable);

        
              
                            
                            })

          
          
        },
        error: function(response) {
            // $('#formloc').text("error finding location");



          console.log(response)
         
         }
       });

    }

    function hidetable(){
        let css_property =
        {
            'visibility':'hidden',
            
        }
         $("#tablediv").css(css_property);
    }
    function showtable(){
let css_property =
        {
            'visibility':'visible',
            
        }
         $("#tablediv").css(css_property);
    }
    </script>

</body>