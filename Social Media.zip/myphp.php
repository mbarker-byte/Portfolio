<?php
session_start();

$action=$_POST['action'];
if($action=='addpost')

{
    userposts();
}
else if($action=='getpost')
{
    get_post();
}

else if($action=='add_comment')
{
    add_comment();
}
else if($action=='get_comment'){
get_comment();
}
else if($action=='delete_comment')
{
    delete_comment();
}
else if($action=='one_comment')
{
    one_comment();
}

else if($action=='one_post')
{
    one_post();
}

else if($action=='save_comment_edit')
{
    save_comment_edit();
}
else if($action=='save_post_edit')
{
    save_post_edit();
}
else if($action=="delete_post")
{
    delete_post();
}

function conn(){

    $user="root";
$password="";
$host="localhost";
$db_name="sqldb";

$con= new mysqli($host,$user,$password,$db_name);
return $con;
}

function userposts(){
$con=conn();
    $stmt = $con->prepare("INSERT INTO `posts`( `content`, `user`) VALUES (?, ?)");  
    $stmt->bind_param("ss", $_POST['content'], $_SESSION["id"] );  


    if($stmt->execute()){  
       

        $stmt->close();  
       $sql = "SELECT posts.id as postid,content as posts,users.username as name,user from posts inner join users on users.id=posts.user";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        


        
    }

    else{
        $response['error'] = "true";   
        echo json_encode($response); 
    }

}
function get_post(){

    $con=conn();
    $sql = "SELECT posts.id as postid,content as posts,users.username as name,user from posts inner join users on users.id=posts.user";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        
}

function add_comment(){

    $con=conn();
    $stmt = $con->prepare("INSERT INTO `comments`( `content`,`post`, `user`) VALUES (?, ?,?)");  
    $stmt->bind_param("sss", $_POST['content'],$_POST['postid'], $_SESSION["id"] );  


    if($stmt->execute()){  
       

        $stmt->close();  
       $sql = "SELECT posts.id as postid,content as posts,users.username as name,posts.user as user from posts inner join users on users.id=posts.user";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        


        
    }

    else{
        $response['error'] = "true";   
        echo json_encode($response); 
    }

}

function get_comment()
{
    $con=conn();
    $sql = "SELECT  comments.id,comments.content,comments.user,users.username as name,user from comments inner join users on users.id=comments.user where post='".$_POST['postid']."'";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 

}

function delete_comment()
{
    $con=conn();
    $stmt = $con->prepare("delete from comments where id=?");  
    $stmt->bind_param("s", $_POST['commentid'] );  
    
    if(!$_SESSION['id']=$_POST['user'])
    {

        $response['error'] = true;   
        echo json_encode($response); 
        
    }
    else{



    if($stmt->execute()){  
       

        $stmt->close();  
       $sql = "SELECT posts.id as postid,content as posts,users.username as name,posts.user as user from posts inner join users on users.id=posts.user";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        


        
    }


    else{
        $response['error'] = "true";   
        echo json_encode($response); 
    }
}
}


function delete_post()
{
    $con=conn();
    $stmt = $con->prepare("delete from posts where id=?");  
    $stmt->bind_param("s", $_POST['postid'] );  
    
    if(!$_SESSION['id']=$_POST['user'])
    {

        $response['error'] = true;   
        echo json_encode($response); 
        
    }
    else{



    if($stmt->execute()){  
       

        $stmt->close();  
       $sql = "SELECT posts.id as postid,content as posts,users.username as name,posts.user as user from posts inner join users on users.id=posts.user";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        


        
    }


    else{
        $response['error'] = "true";   
        echo json_encode($response); 
    }
}
}


function one_comment(){
    $con=conn();
    

    
       

         
       $sql = "SELECT comments.content,comments.user   from comments where comments.id='".$_POST['id']."'";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        


        
    

   
}

function one_post(){
    $con=conn();
    

    
       

         
       $sql = "SELECT posts.content,posts.user   from posts where posts.id='".$_POST['id']."'";
       $result = mysqli_query($con, $sql);

       // set array
       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        


        
    

   
}


function  save_comment_edit()
{
    $con=conn();
    $stmt = $con->prepare("update comments set content=? where id=?");  
    $stmt->bind_param("ss",$_POST['value'], $_POST['id'] );  
    
    if(!$_SESSION['id']=$_POST['user'])
    {

        $response['error'] = true;   
        echo json_encode($response); 
        
    }
    else{



    if($stmt->execute()){  
       

        $stmt->close();  
       $sql = "SELECT posts.id as postid,content as posts,users.username as name,posts.user as user from posts inner join users on users.id=posts.user";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        


        
    }


    else{
        $response['error'] = "true";   
        echo json_encode($response); 
    }
}
}



function  save_post_edit()
{
    $con=conn();
    $stmt = $con->prepare("update posts set content=? where id=?");  
    $stmt->bind_param("ss",$_POST['value'], $_POST['id'] );  
    
    if(!$_SESSION['id']=$_POST['user'])
    {

        $response['error'] = true;   
        echo json_encode($response); 
        
    }
    else{



    if($stmt->execute()){  
       

        $stmt->close();  
       $sql = "SELECT posts.id as postid,content as posts,users.username as name,posts.user as user from posts inner join users on users.id=posts.user";
       $result = mysqli_query($con, $sql);


       $array = array();
       while($row = mysqli_fetch_array($result)){


        $array[] = $row;
      

  
      
      }
      
        $response['error'] = false;   
        $response['data'] = $array; 
        
        
        echo json_encode($response); 
        


        
    }


    else{
        $response['error'] = "true";   
        echo json_encode($response); 
    }
}
}


?>