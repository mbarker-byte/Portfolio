<?php


session_start();


$email = $_POST['email'];  
    $password2 = ($_POST['password']);   

    $user="root";
$password="";
$host="localhost";
$db_name="sqldb";

$con= new mysqli($host,$user,$password,$db_name);

$sql = "SELECT  id,username, email,phone FROM users WHERE `email` = '$email' AND `password` = '$password2'";
$result = $con->query($sql);

if ($result->num_rows > 0) {

  while($row = $result->fetch_assoc()) {
    
    $_SESSION["email"] = $row['email'];
$_SESSION["username"] = $row['username'];
$_SESSION["id"] = $row['id'];
$_SESSION["phone"] =$row['phone'];



$response['error'] = false;   
$response['message'] = 'Login successfull';   
$response['user'] = $user;   




header( "refresh:1;url=posts.php");


  }
} else {
    $response['error'] = true;   
    $response['message'] = 'Invalid username or password'.mysqli_error($con); 
    header( "refresh:1;url=login.php" ); 
}
   
     
   
    
  
 
 echo json_encode($response); 

?>