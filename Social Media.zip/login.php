<html>
    <head>
        <title>
</title>


<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>

<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>

<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.1/mdb.min.css"
  rel="stylesheet"
/>

<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.1/mdb.min.js"
></script>

<style>
    .card{padding:50px;
        margin-top:100px;
        margin-left:300px;
        width:600px;
    }

    </style>


</head>
<body>
  <div class="p-5 bg-image" style="
        background-image: url('https://images.newscientist.com/wp-content/uploads/2020/09/16181027/credit_mohamed-khaki-eyeem-getty-images_web.jpg');
        height: 300px;
        "></div>
<div class="card" style="
        margin-top: -100px;
        background: hsla(0, 0%, 100%, 0.8);
        backdrop-filter: blur(30px);
        ">
<form method="POST" action="loginphp.php">


  <div class="form-outline mb-4">
    <input type="email" id="form2Example1" name="email" class="form-control" />
    <label class="form-label" for="form2Example1">Email address</label>
  </div>


  <div class="form-outline mb-4">
    <input type="password" id="form2Example2" name="password" class="form-control" />
    <label class="form-label" for="form2Example2">Password</label>
  </div>


  <div class="row mb-4">
    <div class="col d-flex justify-content-center">
 
      
    </div>

   
  </div>


  <button type="submit" class="btn btn-primary btn-block mb-4">Sign in</button>


  <div class="text-center">
    <p>Not a member? <a href="register.php">Register</a></p>
  
  </div>
</form>
</div>


</body>
</html>