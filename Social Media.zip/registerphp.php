<?php

$username=$_POST['username'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$password2=$_POST['password'];






$user="root";
$password="";
$host="localhost";
$db_name="sqldb";

$con= new mysqli($host,$user,$password,$db_name);

   
   
    $stmt = $con->prepare("SELECT `email` FROM `users` WHERE `email` = ? ");  
    $stmt->bind_param("s", $email);  
    $stmt->execute();  
    $stmt->store_result();  
   
    if($stmt->num_rows > 0){  
        $response['error'] = true;  
        $response['message'] = 'email already registered';  
        // header( "refresh:3;url=register.php" );
        $stmt->close();  
    }  
    else{  
        $stmt = $con->prepare("INSERT INTO `users`( `username`, `phone`, `email`,`password`) VALUES (?, ?, ?,?)");  
        $stmt->bind_param("ssss", $username, $phone,$email,$password2);  

   
        if($stmt->execute()){  
            // $stmt = $con->prepare("SELECT id, id, username, email, gender FROM users WHERE username = ?");   
            // $stmt->bind_param("s",$username);  
            // $stmt->execute();  
            // $stmt->bind_result($userid, $id, $username, $email, $gender);  
            // $stmt->fetch();  
   
            // $user = array(  
            // 'id'=>$id,   
            // 'username'=>$username,   
            // 'email'=>$email,  
            // );  
   
            $stmt->close();  
   
            $response['error'] = false;   
            $response['message'] = 'User registered successfully';   
            header( "refresh:3;url=login.php" );
            // $response['user'] = $user;   
        }
        else{  
    $response['error'] = true;   
    $response['message'] = 'required parameters are not available'.mysqli_error($con);   
}  

    }
    
        echo json_encode($response);

   





?>
