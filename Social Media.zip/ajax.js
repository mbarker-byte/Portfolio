
     var workinguser;
refreshpage();
function refreshpage(){
$.ajax({
  url: "myphp.php",
  type:"POST",
  data: "json",
  data:{

      
      action:'getpost'

    
    
  
    
  },
  success:function(response){
    
    var myresponse = JSON.parse(response);
    
    console.log(myresponse.data);
     if(!myresponse.error)
     {

         
                  
      $('#posts').empty();
             
                  
                
      $.map(myresponse.data, function(val, i) {


        
        var posts='<div class="card"><div><h5 style="float:left;color:black">'+val.posts+'&nbsp  &nbsp  &nbsp</h5><p style="float:left">'+val.name+'  <button data-bs-toggle="modal" data-bs-target="#editmodal" onclick="one_post('+val.postid+','+val.user+')" type="button" class="btn btn-primary" style="float:right;height:20px;width:20px;font-size:5px;margin-left:5px;padding:2px; border-radius:7px;">E</button> <button onclick="delete_post('+val.user+','+val.postid+')" type="button" class="btn btn-danger" style="float:right;height:20px;width:20px;font-size:5px;padding:2px; border-radius:7px;">X</button></p></div><div class="comments" id="'+val.postid+'commentsdiv"><h6 style="float:left">'+val.comment+'&nbsp  &nbsp</h6><p style="float:left; font-size:15px;">kelvin</p></div><div class="input-group"><span class="input-group-text">my comment</span> <textarea class="form-control" aria-label="With textarea" id="'+i+'mycomment"></textarea><button onclick="add_comment('+val.postid+','+i+')": type="button" class="btn btn-success" style="margin-left:10px; border-radius:7px;">post</button></div></div>';
        $('#posts').append(posts);

        get_comments(val.postid,i);

  
        
                      
                      })

    }
  
   
   
  
    
    
   
                   
                  },
  error: function(response) {
    console.log(response)
   
   }
 });

}

function addpost(){
      

  var userposts = $('#mypost').val();
      
      $.ajax({
        url: "myphp.php",
        type:"POST",
        data: "json",
        data:{

            content:userposts,
            action:'addpost'

          
          
        
          
        },
        success:function(response){
          
          var myresponse = JSON.parse(response);
          
          console.log(myresponse.data);
           if(!myresponse.error)
           {

               
                        
            $('#posts').empty();
                   
                        
                      
            $.map(myresponse.data, function(val, i) {

              
              var posts='<div class="card"><div><h5 style="float:left;color:black">'+val.posts+'&nbsp  &nbsp  &nbsp</h5><p style="float:left">'+val.name+'  <button data-bs-toggle="modal" data-bs-target="#editmodal" onclick="one_post('+val.postid+','+val.user+')" type="button" class="btn btn-primary" style="float:right;height:20px;width:20px;font-size:5px;margin-left:5px;padding:2px; border-radius:7px;">E</button> <button onclick="delete_post('+val.user+','+val.postid+')" type="button" class="btn btn-danger" style="float:right;height:20px;width:20px;font-size:5px;padding:2px; border-radius:7px;">X</button></p></div><div class="comments" id="'+val.postid+'commentsdiv"><h6 style="float:left">'+val.comment+'&nbsp  &nbsp</h6><p style="float:left; font-size:15px;">kelvin</p></div><div class="input-group"><span class="input-group-text">my comment</span> <textarea class="form-control" aria-label="With textarea" id="'+i+'mycomment"></textarea><button onclick="add_comment('+val.postid+','+i+')": type="button" class="btn btn-success" style="margin-left:10px; border-radius:7px;">post</button></div></div>';
     
          $('#posts').append(posts);



        
       get_comments(val.postid,i);
                            
                            })

          }
        
         
         
        
          
          
         
                         
                        },
        error: function(response) {
          console.log(response)
         
         }
       });
      



      
    }





      function add_comment(id,position){
      
        

        var userposts = $("#"+position+"mycomment").val();
            
            $.ajax({
              url: "myphp.php",
              type:"POST",
              data: "json",
              data:{

                postid:id,
                  content:userposts,
                  action:'add_comment'
      
                
                
              
                
              },
              success:function(response){
                
                var myresponse = JSON.parse(response);
                
                
                 if(!myresponse.error)
                 {
      
                     
                              
                  $('#posts').empty();
                         
                              
                            
                  $.map(myresponse.data, function(val, i) {

                    
      
                   
                    var posts='<div class="card"><div><h5 style="float:left;color:black">'+val.posts+'&nbsp  &nbsp  &nbsp</h5><p style="float:left">'+val.name+'  <button data-bs-toggle="modal" data-bs-target="#editmodal" onclick="one_post('+val.postid+','+val.user+')" type="button" class="btn btn-primary" style="float:right;height:20px;width:20px;font-size:5px;margin-left:5px;padding:2px; border-radius:7px;">E</button> <button onclick="delete_post('+val.user+','+val.postid+')" type="button" class="btn btn-danger" style="float:right;height:20px;width:20px;font-size:5px;padding:2px; border-radius:7px;">X</button></p></div><div class="comments" id="'+val.postid+'commentsdiv"><h6 style="float:left">'+val.comment+'&nbsp  &nbsp</h6><p style="float:left; font-size:15px;">kelvin</p></div><div class="input-group"><span class="input-group-text">my comment</span> <textarea class="form-control" aria-label="With textarea" id="'+i+'mycomment"></textarea><button onclick="add_comment('+val.postid+','+i+')": type="button" class="btn btn-success" style="margin-left:10px; border-radius:7px;">post</button></div></div>';
     
            $('#posts').append(posts);
             get_comments(val.postid,i);
              
                    
                                  
                                  })
      
                }
              
               
               
              
                
                
               
                               
                              },
              error: function(response) {
                console.log(response)
               
               }
             });
            
      
      
      
            }
          

       function     get_comments(id,position)
            {
console.log(id)

        
            
              $.ajax({
                url: "myphp.php",
                type:"POST",
                data: "json",
                data:{
  
                  postid:id,
                  action:'get_comment'
        
                  
                  
                
                  
                },
                success:function(response){
                  console.log(response)
                  
                  var myresponse = JSON.parse(response);
                  
                  console.log(myresponse.data);
                   if(!myresponse.error)
                   {




                
                        $('#'+id+'commentsdiv').empty();
                      

                                
                              
                    $.map(myresponse.data, function(val, i) {
        
                     
                      var posts='<h6 style="float:left;font-size:14px;color:blue;">'+val.content+'&nbsp  &nbsp  &nbsp</h6><p style="font-size:10px; width:100%">'+val.name+'<button data-bs-toggle="modal" data-bs-target="#editmodal" onclick="one_comment('+val.id+','+val.user+')" type="button" class="btn btn-primary" style="float:right;height:20px;width:20px;font-size:5px;margin-left:5px;padding:2px; border-radius:7px;">E</button> <button onclick="delete_comment('+val.user+','+val.id+')" type="button" class="btn btn-danger" style="float:right;height:20px;width:20px;font-size:5px;padding:2px; border-radius:7px;">X</button></p>';
                      $($('#'+id+'commentsdiv')).append(posts);
        
                
                      
                                    
                                    })

                                  }
                     
                                
        
                  
                
                 
                 
                
                  
                  
                 
                                 
                                },
                error: function(response) {
                  console.log(response)
                 
                 }
               });
              
            

          }

     

         function  delete_comment(user,id){
workinguser=user;

            $.ajax({
              url: "myphp.php",
              type:"POST",
              data: "json",
              data:{

                commentid:id,
                user:user,
                action:'delete_comment'
      
                
                
              
                
              },
              success:function(response){
                console.log(response)
                
                var myresponse = JSON.parse(response);
                
               
                 if(!myresponse.error)
                 {




              
                      $('#'+id+'commentsdiv').empty();
                    

                              
                            
                  refreshpage();

                                }
                                else{
                                  alert("cannot delete")
                                }
                   
                              
      
                
              
               
               
              
                
                
               
                               
                              },
                        error: function(response) {
                         console.log(response)
               
               }
             });

          }

          var workingid;

          var post="null";
      


          function  one_comment(id,user){
workingid=id;
workinguser=user;

            $.ajax({
              url: "myphp.php",
              type:"POST",
              data: "json",
              data:{

                id:workingid,
                action:'one_comment'
      
                
                
              
                
              },
              success:function(response){
                console.log(response)
                
                var myresponse = JSON.parse(response);

                $.map(myresponse.data, function(val, i) {
        
                  $("#edittxt").val(val.content);
    
            
                  
                                
                                })
                
              
                




              
                              
      
                
              
               
               
              
                
                
               
                               
                              },
                        error: function(response) {
                         console.log(response)
               
               }
             });

          }


          function  savechangecomment(){

console.log("reached")

if(!post=="post"){
            $.ajax({
              url: "myphp.php",
              type:"POST",
              data: "json",
              data:{

                id:workingid,
                user:workinguser,
                value: $("#edittxt").val(),
                action:'save_comment_edit'
      
                
                
              
                
              },
              success:function(response){
                console.log(response)
                
             

              refreshpage();
            
              $('#editmodal').modal('hide');
              
                




              
                              
      
                
              
               
               
              
                
                
               
                               
                              },
                        error: function(response) {
                         console.log(response)
               
               }
             });
            }

            else
            {
              $.ajax({
                url: "myphp.php",
                type:"POST",
                data: "json",
                data:{
  
                  id:workingid,
                  user:workinguser,
                  value: $("#edittxt").val(),
                  action:'save_post_edit'
        
                  
                  
                
                  
                },
                success:function(response){
                  console.log(response)
                  
               
  
                refreshpage();
              
                $('#editmodal').modal('hide');
                
                  
  
  
  
  
                
                                
        
                  
                
                 
                 
                
                  
                  
                 
                                 
                                },
                          error: function(response) {
                           console.log(response)
                 
                 }
               });
            }

          }


          function  delete_post(user,id){
            workinguser=user;
            console.log(id);
            
                        $.ajax({
                          url: "myphp.php",
                          type:"POST",
                          data: "json",
                          data:{
            
                            postid:id,
                            user:user,
                            action:'delete_post'
                  
                            
                            
                          
                            
                          },
                          success:function(response){
                            console.log(response)
                            
                            var myresponse = JSON.parse(response);
                            
                           
                            
            
            
            
                          
                               
                                
            
                                          
                                        
                              refreshpage();
            
                                           
                                          
                  
                            
                          
                           
                           
                          
                            
                            
                           
                                           
                                          },
                                    error: function(response) {
                                     console.log(response)
                           
                           }
                         });
            
                      }
      




                      function  one_post(id,user){
                        post="post"
                        workingid=id;
                        workinguser=user;
                        
                                    $.ajax({
                                      url: "myphp.php",
                                      type:"POST",
                                      data: "json",
                                      data:{
                        
                                        id:workingid,
                                        action:'one_post'
                              
                                        
                                        
                                      
                                        
                                      },
                                      success:function(response){
                                        console.log(response)
                                        
                                        var myresponse = JSON.parse(response);
                        
                                        $.map(myresponse.data, function(val, i) {
                                
                                          $("#edittxt").val(val.content);
                            
                                    
                                          
                                                        
                                                        })
                                        
                                      
                                        
                        
                        
                        
                        
                                      
                                                      
                              
                                        
                                      
                                       
                                       
                                      
                                        
                                        
                                       
                                                       
                                                      },
                                                error: function(response) {
                                                 console.log(response)
                                       
                                       }
                                     });
                        
                                  }
      
