<?php
session_start();
?>
<!DOCTYPE html>
<html>
<title>My Account</title>


<meta name="viewport" content="width=device-width, initial-scale=1">


<link rel="stylesheet" href="css/mycss.css">
<script type="text/javascript" src="js/myjs.js"></script>

<style>
    .styled-table {
    border-radius:10px;
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
	color: #000000;
}
.styled-table thead tr {
    background-color: #009879;
   
    text-align: left;
}
.styled-table th,
.styled-table td {
    padding: 12px 15px;
}
.styled-table tbody tr {
    border-bottom: 1px solid #009879;
}



.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
}
.styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
}
body{	
	background-image: url('https://images.newscientist.com/wp-content/uploads/2020/09/16181027/credit_mohamed-khaki-eyeem-getty-images_web.jpg');
	background-size: cover;
}
    </style>
<body style="padding-left:0px;
  padding-right:0px;
  padding-top:0px;">


<body style="padding-left:0px;
  padding-right:0px;
  padding-top:0px;">
 <div style="color:black;border-radius:70px;background-color:teal;height:100px;width:100px;padding-top:50px;padding-left:50px;postion:fixed;"> <a href="posts.php"  ><u><b style="color:#ffff;">Posts</b></u></a> &nbsp &nbsp &nbsp &nbsp <a href="login.php"><u><b style="color:#ffff;">Logout<b></u></a></div>




<div style="margin-left:25%">

<div class="w3-container w3-teal">
  <h1>My Posts</h1>
</div>



<div class="w3-container">


<table class="styled-table" id="myTable">
    <thead>
        <tr>
            <th>post</th>
            <th>Time</th>
           
            
            
            
        </tr>
    </thead>
    <tbody>


    <?php
$con=mysqli_connect("localhost","root","","sqldb");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


$result = mysqli_query($con,"select * from posts  where `user`='".$_SESSION['id']."';");


while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['content'] . "</a>";
echo "<td>" . $row['created_at'] . "</td>";



echo "</tr>";
}
echo"</tbody>";
echo "</table>";

mysqli_close($con);
?>
</div>





<div class="w3-container w3-teal">
  <h1>My Comments</h1>
</div>



<div class="w3-container">


<table class="styled-table" id="myTable">
    <thead>
        <tr>
            <th>post</th>
            <th>Time</th>
           
            
            
            
        </tr>
    </thead>
    <tbody>


    <?php
$con=mysqli_connect("localhost","root","","sqldb");

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


$result = mysqli_query($con,"select * from comments  where `user`='".$_SESSION['id']."';");


while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['content'] . "</a>";
echo "<td>" . $row['created_at'] . "</td>";



echo "</tr>";
}
echo"</tbody>";
echo "</table>";

mysqli_close($con);
?>
</div>



</div>
      
</body>
</html>
