
<html>
    <head>
        <title>
</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>

<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.1/mdb.min.css"
  rel="stylesheet"
/>

<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.1/mdb.min.js"
></script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>

<script
  type="text/javascript" src="ajax.js"></script>

<style>
    .card{padding:50px;
        margin-top:20px;
        margin-left:300px;
        width:600px;
    }

    .posts{padding:50px;
        margin-top:20px;
        margin-left:150px;
        width:1000px;
        background-color:#C0C0C0;

    }
    .posts textarea{
width:600px 
    }

    
    textarea{
    max-width: 400px;
    height:100px;
    }
body{	
	background-image: url('https://images.newscientist.com/wp-content/uploads/2020/09/16181027/credit_mohamed-khaki-eyeem-getty-images_web.jpg');
	background-size: cover;
}
    </style>


</head>
<body>
<div class="card posts"  >

<div class="makepoast">
  <div> <a href="myaccount.php"><u>My Account</u></a> &nbsp &nbsp &nbsp &nbsp <a href="login.php"><u>Logout</u></a>

</div><br>
<div class="input-group">
  <span class="input-group-text">your post</span>
  <textarea class="form-control" aria-label="With textarea" id="mypost"></textarea>
  <button onclick='addpost()' type="button" class="btn btn-success" style="margin-left:10px; border-radius:7px;">post</button>
</div>



    
</div>



</div>


<div  id="posts" >

  </div>







<div class="modal fade" id="editmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="mb-3">
  
  <input type="email" class="form-control" id="edittxt" placeholder="name@example.com">
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="savechangecomment()">save</button>
      </div>
    </div>
  </div>
</div>
</body>
</html>